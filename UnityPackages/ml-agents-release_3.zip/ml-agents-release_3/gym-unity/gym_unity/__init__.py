# Version of the library that will be used to upload to pypi
__version__ = "0.17.0"

# Git tag that will be checked to determine whether to trigger upload to pypi
__release_tag__ = "release_3"
