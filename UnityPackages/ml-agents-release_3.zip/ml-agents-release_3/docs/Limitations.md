# Limitations

See the package-specific Limitations pages:

- [`com.unity.mlagents` Unity package](../com.unity.ml-agents/Documentation~/com.unity.ml-agents.md#known-limitations)
- [`mlagents` Python package](../ml-agents/README.md#limitations)
- [`mlagents_envs` Python package](../ml-agents-envs/README.md#limitations)
- [`gym_unity` Python package](../gym-unity/README.md#limitations)
