# Doxygen files

To generate the API reference as HTML files, run:

    doxygen dox-ml-agents.conf
